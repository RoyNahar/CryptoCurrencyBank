<?php

namespace byrokrat\banking\Exception;

/**
 * Exception thrown when a check digit is invalid
 */
class InvalidCheckDigitException extends InvalidAccountNumberException
{
}
