<?php

namespace byrokrat\banking;

/**
 * Base exception, all thrown exceptions implements this interface
 */
interface Exception
{
}
